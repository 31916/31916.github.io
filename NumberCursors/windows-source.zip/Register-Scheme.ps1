[CmdletBinding(SupportsShouldProcess)]
param()

$ErrorActionPreference = 'Stop'
$schemeName = 'Number Cursors v4 (#CCCCCC)'
$files = @(
    'Arrow.cur', 'Help.cur', 'AppStarting.ani', 'Wait.ani',
    'Crosshair.cur', 'IBeam.cur', 'NWPen.cur', 'No.cur',
    'SizeNS.cur', 'SizeWE.cur', 'SizeNWSE.cur', 'SizeNESW.cur',
    'SizeAll.cur', 'UpArrow.cur', 'Hand.cur', 'Pin.cur', 'Person.cur'
)

$source = Join-Path $PSScriptRoot 'cursors'
$destination = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'NumberCursors\CCCCCC-v4'
$registryKey = 'HKCU:\Control Panel\Cursors\Schemes'
$sourceFiles = foreach ($file in $files) {
    $path = Join-Path $source $file
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing cursor: $path"
    }
    $path
}
if ($destination.Contains(',')) {
    throw 'The scheme path contains a comma, which Windows uses to separate cursor paths.'
}
$scheme = ($files | ForEach-Object { Join-Path $destination $_ }) -join ','

if ($PSCmdlet.ShouldProcess($schemeName, "Copy cursors to $destination and register the scheme for this user")) {
    New-Item -Path $destination -ItemType Directory -Force | Out-Null
    Copy-Item -LiteralPath $sourceFiles -Destination $destination -Force

    if (-not (Test-Path -LiteralPath $registryKey)) {
        New-Item -Path $registryKey -Force | Out-Null
    }
    New-ItemProperty -LiteralPath $registryKey -Name $schemeName -Value $scheme -PropertyType String -Force | Out-Null
    Write-Output "Registered '$schemeName'. Open main.cpl, select the Pointers tab, and choose the scheme."
}
