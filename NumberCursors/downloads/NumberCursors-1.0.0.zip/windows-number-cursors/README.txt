﻿数字カーソル — Windows 用 17 種類

全ファイルは #CCCCCC と透過背景で、32・48・64 px の画像を収録しています。
preview.png で割り当てと実寸 32 px を確認できます。
wait-preview.png と working-preview.png は動きの見本です。

一括登録
1. ZIP を展開し、展開したフォルダーをターミナルで開きます。
2. 次のコマンドを実行して、現在のユーザーにカーソルのデザインを登録します。
   powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File .\Register-Scheme.ps1
3. Win + R で main.cpl を開き、「ポインター」タブの「デザイン」で
   Number Cursors (#CCCCCC) を選んで「適用」を押します。
   ファイルは %LOCALAPPDATA%\NumberCursors\CCCCCC にコピーされます。

個別に設定する場合
「ポインター」タブで設定する項目を選び、「参照」から cursors フォルダーの
対応ファイルを指定します。

通常の選択                    Arrow.cur         斜めの 4
ヘルプの選択                  Help.cur          斜めの 4 ＋ 小さな 2
バックグラウンドで作業中      AppStarting.ani   斜めの 4 ＋ 小さな 6↔9 の回転
待ち状態                      Wait.ani          6↔9 の回転
精密選択                      Crosshair.cur     小さな 0 ＋ 中心点
テキスト選択                  IBeam.cur         細い 1
手書き                        NWPen.cur         斜めの 2
利用不可                      No.cur            0 ＋ 斜めの 1
上下に拡大・縮小              SizeNS.cur        外側に先端を向けた 7 を上下に配置
左右に拡大・縮小              SizeWE.cur        外側に先端を向けた 7 を左右に配置
斜めに拡大・縮小（↖↘）        SizeNWSE.cur      外側に先端を向けた 7 を左上・右下に配置
斜めに拡大・縮小（↗↙）        SizeNESW.cur      外側に先端を向けた 7 を右上・左下に配置
移動                          SizeAll.cur       8 ＋ 四方向の短い 1
代替選択                      UpArrow.cur       直立の 4
リンクの選択                  Hand.cur          7
場所の選択                    Pin.cur           ピン形の 6
人物の選択                    Person.cur        人型の 8
