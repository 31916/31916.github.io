数字カーソル v4 — Windows 用 17 種類

全ファイルは #CCCCCC と透過背景で、32・48・64 px の画像を収録しています。
preview.png で割り当てと実寸 32 px を確認できます。
wait-preview.png と working-preview.png は動きの見本です。

一括登録
1. ZIP を展開し、展開したフォルダーをターミナルで開きます。
2. 次のコマンドを実行して、現在のユーザーにカーソルのデザインを登録します。
   powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File .\Register-Scheme.ps1
3. Win + R で main.cpl を開き、「ポインター」タブの「デザイン」で
   Number Cursors v4 (#CCCCCC) を選んで「適用」を押します。
   ファイルは %LOCALAPPDATA%\NumberCursors\CCCCCC-v4 にコピーされます。

個別に設定する場合
「ポインター」タブで設定する項目を選び、「参照」から cursors フォルダーの
対応ファイルを指定します。

通常の選択                    Arrow.cur         斜めの 4
ヘルプの選択                  Help.cur          斜めの 4 ＋ 細い 2
バックグラウンドで作業中      AppStarting.ani   斜めの 4 ＋ 小さな 6↔9 の回転
待ち状態                      Wait.ani          6↔9 の回転
精密選択                      Crosshair.cur     シンプルな 8
テキスト選択                  IBeam.cur         細い 1
手書き                        NWPen.cur         添付の字形に沿った 1 を鉛筆の向きに回転
利用不可                      No.cur            添付の字形に沿った 0 ＋ 中央の斜線
上下に拡大・縮小              SizeNS.cur        外側に先端を向けた 7 を上下に配置
左右に拡大・縮小              SizeWE.cur        外側に先端を向けた 7 を左右に配置
斜めに拡大・縮小（↖↘）        SizeNWSE.cur      外側に先端を向けた 7 を左上・右下に配置
斜めに拡大・縮小（↗↙）        SizeNESW.cur      外側に先端を向けた 7 を右上・左下に配置
移動                          SizeAll.cur       四方向を向く 7 を組み合わせた形
代替選択                      UpArrow.cur       上向きの 7
リンクの選択                  Hand.cur          シンプルな 3
場所の選択                    Pin.cur           3 ＋ 右下に小さな 5
人物の選択                    Person.cur        3 ＋ 右下に小さな 5
